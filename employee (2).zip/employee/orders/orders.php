<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" href="style.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1"><br>
	<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1"/>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
</head>
<style type="">
.header{
	  background-color: #7792a3;
	padding: 10px;
	text-align: center;
	height: 63px;
	margin-top:-20px;
background-image: url("logo.png");
	background-size: 70px 55px;
	background-repeat: no-repeat;
	background-position: 3% 40%;



}
a.nav1{
	
	color:white;
	background-color: #7792a3;
	margin-left: -700px;
	vertical-align: text-top;
	margin-top: 20px;
	font-family: "Times New Roman",Times,serif;
	font-size: 20px;
	
}
a.nav1:link{
	text-decoration: none;
}
a.nav2:link{
	text-decoration: none;
}
a.nav1:visited{
	text-decoration: none;
}
a.nav2:visited{
	text-decoration: none;
}

a.nav1:hover{
	text-decoration: underline;
	text-decoration-color: blue;
}
a.nav2:hover{
	text-decoration: underline;
	text-decoration-color: blue;
}
a.nav1:active{
	color: black;
}
a.nav2:active{
	color:black;
}

a.nav2{
	margin-top: -90px;
	color:white;
	background-color: #7792a3;
	vertical-align: text-top;
	font-family: "Times New Roman",Times,serif;
	font-size: 20px;
}
</style>
	<body>
		<div class="header">
	    
	    </div>
        <br><br><br>
		<div class="col-md-2"></div>
	    <div class="col-md-9 well">
		<h3 class="text-primary">Total Price Of Product</h3>
		<hr style="border-top:1px dotted #ccc;"/>
		<div class="col-md-4">
			<form method="POST" action="save_product.php">
				<div class="form-group">
					<label>Product Name</label>
					<input type="text" name="product" class="form-control" required="required"/>
				</div>
				<div class="form-group">				
					<label>Price</label>
					<input type="number" min="0" name="price" class="form-control" required="required"/>
				</div>
				<center><button class="btn btn-primary" name="add">Add Product</button></center>
			</form>
		</div>
	</body>