<!DOCTYPE html>
<html>
<head>
    <title>Insert Page page</title>
</head>

<body>
    <center>
        <?php
        // servername => localhost
        // username => root
        // password => empty
        // database name => staff
        //localhost=hostname, username=root 
        $conn =  mysqli_connect("localhost", "root", "", "admin");

        // Check connection
        if ($conn === false) {
            die("ERROR: Could not connect."
                . mysqli_connect_error());
        }

        // Taking all 5 values from the form data(input)
        $emailid = $_REQUEST['emailid'];
        $pass = $_REQUEST['pass'];

        // Performing insert query execution
        // here our table name is users  

        $sql1 = "SELECT * FROM admin_user WHERE emailid = '$emailid' && pass = $pass";
        $result = mysqli_query($conn, $sql1);
        if ($result->num_rows > 0)
         {
       //   echo "welcome";
      //    <a href="\employee\basic_command\index.php"></a>
            header('Location:\employee\basic_command\index.php');
        } else {
            $message = "wrong credentials";
            echo "<script type='text/javascript'>alert('$message'); window.location.href = 'index.html';</script>";
        }
        // Close connection
        mysqli_close($conn);
        ?>
     
    </center>
</body>

</html>