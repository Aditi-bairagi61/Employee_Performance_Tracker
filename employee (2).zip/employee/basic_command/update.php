<?php
	include('conn.php');
	$id=$_GET['id'];
	
	$empname=$_POST['emp_name'];
	$location=$_POST['location'];
	$mobileno=$_POST['mobileno'];
	
	mysqli_query($conn,"update `user` set emp_name='$empname', location='$location',mobileno='$mobileno' where userid='$id'");
	header('location:index.php');
?>