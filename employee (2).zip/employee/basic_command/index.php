<!DOCTYPE html>
<html>
<head>
<title></title>
 <link rel="stylesheet" href="style.css">
 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width,initial-scale=1"><br>
 
</head>
<style>
   
	tr:nth-child(even)
 {
 	background-color:#e6e2d3;
 }
 table{
 	width:70%;
 	margin-left: 200px;
 	border-collapse: collapse;

 	border-color: solid black;
 	margin-top: -60px;
 }
 th{
 	height: 40px;
 	background-color: #e3dd9a;
 }
 td{
 	background-color: #dfe3c5;
 	height: 30px;
}
.header{
	background-color: #7792a3;
	padding: 10px;
  height: 43px;
	margin-top: -90px;
	background-image: url("logo3.png");
	background-size: 70px 55px;
	background-repeat: no-repeat;
	background-position: 3% 40%;
	 
}
 #ex{
	border:10px ;
	padding:20px;
	background-color: #d8e8ed;
	background-repeat: no-repeat;
	background-size: 100px 100px;
	width: 350px;
	height: 150px;
	background-attachment: fixed;
}
body{
	background-color:#c5c9b3;
	margin:0;
}
p{
	color:#003153;
	letter-spacing: 3px;
	background-color: none;
	width: 500px;
	font-size: 40px;
	margin-left: 450px;
}
label{
	background-color: solid gray;
}
h3{
	text-align: left;
	vertical-align: text-top;
}
a:link{
	color: white;
	background-color:#fa5a5a;
}
a:hover{
	background-color: red;
	}
a:active{
	background-color: hotpink;
	
}
a.nav{
	
	text-decoration: none;
}
a.nav:link{
	
	background-color:#206f91;
}
a.nav:hover{
	background color:green;
}
a.nav:active{
	color:green;
	}
input[type=submit]{
	background-color: #4CAF50;
	color: white;
	padding: 7px 13px;
	margin: 1px 70px;
	cursor: pointer;
}
a.nav1{
	color:white;
	background-color: #7792a3;
	margin-left: -700px;
	vertical-align: text-center;
	margin-top: 20px;
	font-size: 20px;
	position: relative;
	right: -170px;
	margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;
}
a.nav1:link{
	text-decoration: none;
}
a.nav2:link{
	text-decoration: none;
}
a.nav1:visited{
	text-decoration: none;
}
a.nav2:visited{
	text-decoration: none;
}
a.nav3:visited{
	text-decoration: none;
}
a.nav4:visited{
	text-decoration: none;
}
a.nav5:visited{
	text-decoration: none;
}
a.nav1:hover{
	text-decoration: underline;
	text-decoration-color: white;
}
a.nav2:hover{
	text-decoration: underline;
	text-decoration-color: white;
}
a.nav3:hover{
	text-decoration: underline;
	text-decoration-color: white;
}
a.nav4:hover{
	text-decoration: underline;
	text-decoration-color: white;
}
a.nav5:hover{
	text-decoration: underline;
	text-decoration-color: white;
}
a.nav1:active{
	color: black;
}
a.nav2:active{
	color:black;
}
a.nav3:active{
	color:black;
}
a.nav4:active{
	color:black;
}
a.nav5:active{
	color:black;
}
a.nav2{
	margin-top: -90px;
	color:white;
	background-color: #7792a3;
	font-size: 20px;
	position: relative;
	right:-140px;
	margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;
}
a.nav3{
	color:white;
	background-color: #7792a3;
	margin-left: -700px;
	margin-top: 20px;
	font-size: 20px;
	position: relative;
	left: 120px;
	text-decoration: none;
	margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;
}
a.nav4{
		color:white;
	background-color: #7792a3;
	margin-left: -700px;
	vertical-align: text-center;
	margin-top: 20px;
	font-size: 20px;
	position: relative;
	left: 90px;
	text-decoration: none;
	margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;
}
a.nav5{
	color:white;
	background-color: #7792a3;
	margin-left: -700px;
	vertical-align: text-center;
	margin-top: 20px;
	font-size: 20px;
	position: relative;
	left: 310px;
	text-decoration: none;
	margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;
}


 </style><br><br><br><br>

<body>
	
	<div class="header">
	
      <a class="nav1" href="\employee\basic_command\index.php"><b>Add&nbsp;  Employee</b></a>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       
    <a class="nav2" href="\employee\PHP - Calculate Total Price In Table\index.php"><b>Add &nbsp; Product</b></a>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <a class="nav3" href="\employee\bill_payment\index.php"><b>Employee&nbsp; Performance </b></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <a class="nav4" href="\employee\bill_payment\datedata.php"><b>Calander</b></a>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     <a class="nav5" style="margin: 0px 0px 0px 20px;" href="/employee/admin-login/index.html"><b>Logout</b></a>
     

	</div>
    <form  method="POST" action="add.php"><br>
	<div id="ex">
		
		
			<b><label >Employee Name:</label></b>
			<input type="text" name="emp_name" required="" ><br><br>
		
			<b><label>Location:</label></b><input type="text" name="location" required="" ><br><br>
		
			<b><label>Mobile:</label></b><input type="number" name="mobileno" required=""><br><br>
			<input type="submit"  name="add">
			<!-- <button class="btn btn-success" name="add">Submit</button>  -->
		</form>
	</div>
	<b><p><i>Inserted   Records   Table</p></b></i>
	<div>
		<table border="1">
			<thead>
				<th>Empname</th><br>
				<th>Location</th><br>
				<th>Mobile</th><br>
				<th>Action</th>
				</thead>
			<tbody>
				<?php
					include('conn.php');
					$query=mysqli_query($conn,"select * from `user`");
					while($row=mysqli_fetch_array($query)){
						?>
						<tr>
							<td><?php echo $row['emp_name']; ?></td>
							<td><?php echo $row['location']; ?></td>
							<td><?php echo $row['mobileno']; ?></td>
							<td>
								&nbsp;
								<a class="nav" href="edit.php?id=<?php echo $row['userid']; ?>" class="btn btn-info">E d i t</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								<a href="delete.php?id=<?php echo $row['userid']; ?>"  class="btn btn-danger">D e l e t e</a>
							</td>
						</tr>
						<?php
					}
				?>

			</tbody>
		</table>
	</div>
			 <!--	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>-->
</body>
</html>