<?php
	include('conn.php');
	$empname=$_POST['emp_name'];
	$location=$_POST['location'];
	$mobileno=$_POST['mobileno'];


mysqli_query($conn,"insert into `user` (emp_name,location,mobileno) values ('$empname','$location','$mobileno')");

	header('location:index.php');
	
	

?>
