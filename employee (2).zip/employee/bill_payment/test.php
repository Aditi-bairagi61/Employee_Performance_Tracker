
<?php 
$conn = mysqli_connect("localhost","root","","bill_reciept");
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

if(ISSET($_POST['submit'])){
   $empname=$_POST['emp_name'];
   $product=$_POST['product_name'];
    $price=$_POST['product_price'];
    $qty=$_POST['product_qty'];
    $sql="INSERT INTO `orders`(emp_name,product_name,product_price,product_qty)values('$empname','$product','$price','$qty')";
    if(mysqli_query($conn,$sql))
    {
      echo "data not inser";
    }
    {

      header('location:test.php');
    }

}

                  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<form method="POST">
<div class="container">
  
  <table class="table">
    
    <tbody>
      <tr>
         <th>Empname</th>
        <td style="width:19%">
                        <select  name="emp_name" id="refresh"   class="form-control">
                              <?php 
                              $conn = mysqli_connect("localhost","root","","basic_command");

                               // Check connection
                                  if (mysqli_connect_errno())
                                   {
                               echo "Failed to connect to MySQL: " . mysqli_connect_error();
                                   }
                                 $sql = "SELECT * FROM product";
                                 $query = mysqli_query($conn,$sql);
                                 while($row = mysqli_fetch_assoc($query)){
                                 ?>
                              <option id="<?php echo $row['userid']; ?>" value="<?php echo $row['emp_name']; ?>" class="vegi custom-select">
                                 <?php echo $row['emp_name']; ?>
                              </option>
                              <?php  }?>   
                           </select>


 
</td>
      </tr>  

      <tr class="success">
         <th>product name</th>
         <td style="width:19%">
         <select name="product_name" id="refresh"  class="form-control" class="btn" >
                              <?php 
                              $conn = mysqli_connect("localhost","root","","db_price");

                                //Check connection
                                  if (mysqli_connect_errno())
                                   {
                               echo "Failed to connect to MySQL: " . mysqli_connect_error();
                                   }
                                 $sql = "SELECT * FROM product";
                                 $query = mysqli_query($conn,$sql);
                                 while($row = mysqli_fetch_assoc($query)){
                                 ?>
                              <option id="<?php echo $row['product_id']; ?>" value="<?php echo $row['product_name']; ?>" class="vegitable custom-select">
                                 <?php echo $row['product_name']; ?>
                              </option>
                              <?php  }?>   
                           </select>
                        </td>
        
      </tr>

      <tr>
         <th>price</th>
                           <td style="width:19%"> 
                           <input type="text" name="product_price" id="ddlFruits"/>
                         </td>
                        
      </tr>
      <tr class="danger">
         <th>qty</th>
        <td style="width:1%">
                          <input type="number" name="product_qty" id="refresh" min="0" value="0" class="form-control">
                        </td>
                        <td>
                           
       
      </tr>
      
      <td><button id="add" name="submit" value="submit" class="btn btn-primary">Add</button></td>
      <td><input type="button" id="btnReset" value="Reset" onclick="Reset();" /></td>

      
    </tbody>
  </table>
</div>
<script type="text/javascript">
    function Reset() {
        var dropDown = document.getElementById("ddlFruits");
        dropDown.selectedIndex = 0;
    }
</script>

                              </form>
                                 
</body>
