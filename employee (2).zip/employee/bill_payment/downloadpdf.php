

<?php
require('fpdf/fpdf.php');
// Database Connection 
$conn = new mysqli('localhost', 'root', '', 'bill_reciept');
//Check for connection error
if($conn->connect_error){
  die("Error in DB connection: ".$conn->connect_errno." : ".$conn->connect_error);    
}
// Select data from MySQL database
$select = "SELECT * FROM `orders`";
$result = $conn->query($select);
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',9);
while($row = $result->fetch_object()){
  $id = $row->id;
  $pid = $row->product_id;
  $emp=$row->emp_name;
  $name=$row->product_name;
   $price=$row->product_price;
  $qty = $row->product_qty;
 
  $date = $row->reg_date;
  $total=$price*$qty;
  
  $pdf->Cell(10,10,$id,1);
  //$pdf->Cell(20,10,$pid,1);
  $pdf->Cell(50,10,$emp,1);
  $pdf->Cell(40,10, $name,1);
   
  $pdf->Cell(20,10, $price,1);
   $pdf->Cell(10,10, $qty,1);
    $pdf->Cell(20,10, $total,1);
   $pdf->Cell(40,10, $date,1);
   
  $pdf->Ln();
}
$file=time().'.pdf';
$pdf->Output($file,'D');
?>