<?php 
$conn = new mysqli('localhost', 'root', '', 'bill_reciept');
    

    

    $output = '';

    $sql="SELECT orders  WHERE emp_name = 
    '".$_POST["product_price"]."'";

    $result = mysqli_query($conn,$sql);

    $output = '<option value="">Select Place</option>';

    while($row=mysqli_fetch_array($result)){

        $output = '<option 

        value .= "'.$row["product_price"].'">'.$row["product_price"].'</option>';

    }
    echo $output;
    ?>