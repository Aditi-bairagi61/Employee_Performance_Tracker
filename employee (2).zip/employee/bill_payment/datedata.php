<?php
$con=mysqli_connect('localhost','root','','bill_reciept');
$sub_sql="";
$toDate=$fromDate="";
if(isset($_POST['submit'])){
  $from=$_POST['from'];
  $fromDate=$from;
  $fromArr=explode("/",$from);
  $from=$fromArr['2'].'-'.$fromArr['1'].'-'.$fromArr['0'];
  $from=$from." 00:00:00";
 
  $to=$_POST['to'];
  $toDate=$to;
  $toArr=explode("/",$to);
  $to=$toArr['2'].'-'.$toArr['1'].'-'.$toArr['0'];
  $to=$to." 23:59:59";
 
  $sub_sql= " where reg_date >= '$from' && reg_date <= '$to' ";
}

$res=mysqli_query($con,"select * from orders $sub_sql  ");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Contact Us</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
</head>
<style type="text/css">
  .header{
    background-color: #7792a3;
  padding: 10px;
  height: 83px;
  margin-top:-20px;
  background-image: url("logo3.png");
  background-size: 70px 55px;
  background-repeat: no-repeat;
  background-position: 3% 85%;
 display: flex;
  justify-content: center;
  align-items: center;
}

a.nav1:link{
  text-decoration: none;
}
a.nav2:link{
  text-decoration: none;
}
a.nav3:link{
  text-decoration: none;
}
a.nav4:link{
  text-decoration: none;
}
a.nav5:link{
  text-decoration: none;
}
a.nav1:visited{
  text-decoration: none;
}
a.nav2:visited{
  text-decoration: none;
}
a.nav3:visited{
  text-decoration: none;
}
a.nav4:visited{
  text-decoration: none;
}
a.nav5:visited{
  text-decoration: none;
}
a.nav1:hover{
  text-decoration: underline;
  text-decoration-color: white;
}
a.nav2:hover{
  text-decoration: underline;
  text-decoration-color: white;
}
a.nav3:hover{
  text-decoration: underline;
  text-decoration-color: white;
}
a.nav4:hover{
  text-decoration: underline;
  text-decoration-color: white;
}
a.nav5:hover{
  text-decoration: underline;
  text-decoration-color: white;
}
a.nav1:active{
  color: black;
}
a.nav2:active{
  color:black;
}
a.nav3:active{
  color: black;
}
a.nav4:active{
  color: black;
}
a.nav5:active{
  color: black;
}
a.nav1{
  color:white;
  background-color: #7792a3;
  position: relative;
  font-family: "Times New Roman",Times,serif;
  font-size: 20px;
  right: -168px;
   margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;
}
a.nav2{
  color:white;
  background-color: #7792a3;
  position: relative;
  font-family: "Times New Roman",Times,serif;
  font-size: 20px;
  left: 30px; 
  text-align: center;
   margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;
}
a.nav3{
  margin-top: -50px;
  color:white;
  background-color: #7792a3;
  position: relative;
  font-family: "Times New Roman",Times,serif;
  font-size: 15px;
  margin-left: -200px;
  margin-right: 50px;
  left: -25px;
  margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;
}
a.nav4{
  margin-top: -50px;
  color:white;
  background-color: #7792a3;
  position: relative;
  font-family: "Times New Roman",Times,serif;
  font-size: 20px;
  left: -46px;
   margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;
}
a.nav5{
  margin-top: -50px;
  color:white;
  background-color: #7792a3;
  font-family: "Times New Roman",Times,serif;
  position: relative;
  font-size: 20px;
  left: 75px;
   margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
  padding-top: 11px;
}
}
</style>
<body>
  <div class="header">
   <a class="nav1" href="\employee\basic_command\index.php"><b>Add&nbsp;  Employee</b></a>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <a class="nav2" href="\employee\PHP - Calculate Total Price In Table\index.php"><b>Add &nbsp; Product</b></a>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <a class="nav3" href="\employee\bill_payment\index.php"><b>Employee&nbsp; Performance </b></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <a class="nav4" href="\employee\bill_payment\datedata.php"><b>Calander</b></a>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     <a class="nav5"  href="/employee/admin-login/index.html"><b>Logout</b></a>
        </div>
      <div class="container">
  <br/><h1>Contact Us</h1><br/>
 <div>
  <form method="post">
    <label for="from">From</label>
    <input type="text" id="from" name="from" required value="<?php echo $fromDate?>">
    <label for="to">To</label>
    <input type="text" id="to" name="to" required value="<?php echo $toDate?>">
    <input type="submit" name="submit" value="Search"  class="btn btn-info">
  </form>
  </div>
  <br/><br/>
  <?php if(mysqli_num_rows($res)>0){?>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>id</th>
        <th>empname</th>
        <th>productName</th>
        <th>price</th>
        <th>qty</th>
      <th>total</th>
    <th>date</th>
       </tr>
    </thead>
    <tbody>
      <?php while($row=mysqli_fetch_assoc($res)){
           $price=$row['product_price'];
                     $qty=$row['product_qty'];
                     ?>
      <tr>
      <td><?php echo $row['product_id']?></td>
        <td><?php echo $row['emp_name']?></td>
    <td><?php echo $row['product_name']?></td>
    <td><?php echo $row['product_price']?></td>
    <td><?php echo $row['product_qty']?></td>
       <td class="itotal"><?php echo $total=$price*$qty?></td> 
      <td><?php echo $row['reg_date']?></td>

 
     

      </tr>
    <?php } ?>
      <?php
include 'total1.php';
?>  
 
    </tbody>
 
     
  </table>
    
  <?php } else {
  echo "No data found";  
  }
  ?>
   
</div>
<script>
  $( function() {
    var dateFormat = "dd/mm/yy",
      from = $( "#from" )
        .datepicker({
          defaultDate: "+1w",
          changeMonth: true,
          numberOfMonths: 1,
      dateFormat:"dd/mm/yy",
        })
        .on( "change", function() {
          to.datepicker( "option", "minDate", getDate( this ) );
        }),
      to = $( "#to" ).datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        numberOfMonths: 1,
    dateFormat:"dd/mm/yy",
      })
      .on( "change", function() {
        from.datepicker( "option", "maxDate", getDate( this ) );
      });
 
    function getDate( element ) {
      var date;
      try {
        date = $.datepicker.parseDate( dateFormat, element.value );
      } catch( error ) {
        date = null;
      }
 
      return date;
    }
  } );
  </script>
  <center><form class="form-inline" method="post" action="downloadpdf.php">
<button type="submit" id="pdf" name="generate_pdf" class="btn btn-primary"><i class="fa fa-pdf" aria-hidden="true"></i>
Download PDF</button></center>
</body>
</html>