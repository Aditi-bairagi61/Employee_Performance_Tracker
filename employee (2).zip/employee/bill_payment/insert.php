<?php
//insert.php;

if(isset($_POST["id"]))
{
 $connect = new PDO("mysql:host=localhost;dbname=bill_reciept", "root", "");
 $order_id = uniqid();
 for($count = 0; $count < count($_POST["id"]); $count++)
 {  
  $query = "INSERT INTO orders
  (id, product_id,emp_name, product_name, product_price,product_qty) 
  VALUES (:id, :product_id, :emp_name, :product_name,:product_price,:product_qty)
  ";
  $statement = $connect->prepare($query);
  $statement->execute(
   array(
    ':id'   => $id,
    ':product_id'  => $_POST["product_id"][$count], 
    ':emp_name' => $_POST["emp_name"][$count], 
    ':product_name'  => $_POST["product_name"][$count],
     ':product_price' => $_POST["product_price"][$count], 
      ':product_qty' => $_POST["product_qty"][$count], 
   )
  );
 }
  if ($product_qty == 0) {
        $errors[] = 'Please provide the quantity.';
    }
 $result = $statement->fetchAll();

 if(isset($result))
 {
  echo 'ok';
 }
}
?>