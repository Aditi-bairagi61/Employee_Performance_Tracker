<?php
	$id=$_GET['id'];
	include('db.php');
	mysqli_query($conn,"delete from `orders` where id='$id'");
	header('location:index.php');
?>