<?php
   //include("db2.php");
?>
<?php
$conn = mysqli_connect("localhost","root","","bill_reciept");
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

if(ISSET($_POST['submit'])){
   $proid=$_POST['product_id'];
   $empname=$_POST['emp_name'];
   $product=$_POST['product_name'];
    $price=$_POST['product_price'];
    $qty=$_POST['product_qty'];
    $sql="INSERT INTO `orders`(emp_name,product_name,product_price,product_qty)values('$empname','$product','$price','$qty')";
    if(mysqli_query($conn,$sql))
    {
      echo "data not insert";
    }
    {

      header('location:index.php');
    }

}

                  ?>
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <title>Add or Remove Selectpicker Dropdown Dynamically in PHP using Ajax jQuery</title>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.14.0-beta2/dist/css/bootstrap-select.min.css">

      <script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.14.0-beta2/dist/js/bootstrap-select.min.js"></script>
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
      <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
   </head>
      <title>Document</title>
  <style>
.header{
    background-color: #7792a3;
  padding: 10px;
  height: 83px;
  margin-top:-20px;
  background-image: url("logo3.png");
  background-size: 70px 55px;
  background-repeat: no-repeat;
  background-position: 3% 85%;
 display: flex;
  justify-content: center;
  align-items: center;
   
}

a.nav1:link{
  text-decoration: none;
}
a.nav2:link{
  text-decoration: none;
}
a.nav3:link{
  text-decoration: none;
}
a.nav4:link{
  text-decoration: none;
}
a.nav5:link{
  text-decoration: none;
}
a.nav1:visited{
  text-decoration: none;
}
a.nav2:visited{
  text-decoration: none;
}
a.nav3:visited{
  text-decoration: none;
}
a.nav4:visited{
  text-decoration: none;
}
a.nav5:visited{
  text-decoration: none;
}
a.nav1:hover{
  text-decoration: underline;
  text-decoration-color: white;
}
a.nav2:hover{
  text-decoration: underline;
  text-decoration-color: white;
}
a.nav3:hover{
  text-decoration: underline;
  text-decoration-color: white;
}
a.nav4:hover{
  text-decoration: underline;
  text-decoration-color: white;
}
a.nav5:hover{
  text-decoration: underline;
  text-decoration-color: white;
}
a.nav1:active{
  color: black;
}
a.nav2:active{
  color:black;
}
a.nav3:active{
  color: black;
}
a.nav4:active{
  color: black;
}
a.nav5:active{
  color: black;
}
a.nav1{
  color:white;
  background-color: #7792a3;
  position: relative;
  font-family: "Times New Roman",Times,serif;
  font-size: 20px;
  right: -169px;
   margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;
}
a.nav2{
  color:white;
  background-color: #7792a3;
  position: relative;
  font-family: "Times New Roman",Times,serif;
  font-size: 20px;
  left: 10px; 
  text-align: center;
   margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;
}
a.nav3{
  margin-top: -50px;
  color:white;
  background-color: #7792a3;
  position: relative;
  font-family: "Times New Roman",Times,serif;
  font-size: 20px;
  margin-left: -200px;
  margin-right: 50px;
  left: -55px;
  margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;
}
a.nav4{
  margin-top: -50px;
  color:white;
  background-color: #7792a3;
  position: relative;
  font-family: "Times New Roman",Times,serif;
  font-size: 20px;
  left: -10px;
   margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;
}
a.nav5{
  margin-top: -50px;
  color:white;
  background-color: #7792a3;
  font-family: "Times New Roman",Times,serif;
  position: relative;
  font-size: 20px;
  left: 100px;
   margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
  padding-top: 11px;
}
}
 .result{
         color:red;
        }
        td
        {
          text-align:center;
        }
        select{
          right :80px;
        }
        .btn{
          padding-right: 30px;
        }
       .bbtn{
        text-align: center;

       }
 </style>
  </head>
   <body>
    <div class="header">
    <a class="nav1" href="\employee\basic_command\index.php"><b>Add&nbsp;  Employee</b></a>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a class="nav2" href="\employee\PHP - Calculate Total Price In Table\index.php"><b>Add &nbsp; Product</b></a>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <a class="nav3"  href="\employee\bill_payment\index.php"><b>Employee&nbsp; Performance </b></a>
   <a class="nav4" href="\employee\bill_payment\datedata.php"><b>Calander</b></a>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <a class="nav5"  href="/employee/admin-login/index.html"><b>Logout</b></a>
       </div>
      <div class="date" align="left"><
</div>
      <section class="mt-3">
         <div class="container-fluid">
         <h2 class="text-center" style="color:green"> Ashwamedh Agro Chemical Pvt.Ltd </h2>
         <h6 class="text-center"> </h6>
         <div class="row">
            <div class="col-md-6  mt-4 ">
               <table class="table" style="background-color:#f5f5f5;">
                  <div class="container">
         <br />
          <form method="post" id="insert_form">
                  <div class="table-repsonsive">
                     <span id="error"></span>
                     <table class="table table-bordered" id="item_table">
                        <tr id="">
                           <th style="width: 19%">Employee Name</th>
                           <th style="width: 19%">Product Name</th>
                           <th style="width: 19%">Price</th>
                           <th>Qty</th>
                      <th><button type="button" name="add"  id="addRow" class="btn btn-success btn-sm add"><i class="fas fa-plus"></i></button></th>
 
                  </tr>
                   <div id="inputFormRow">
                <div class="input-group mb-8">

                 
       <td style="width: 25%">
                        <select  name="emp_name" id="vegi"   class="form-control">
                              <?php
                              $conn = mysqli_connect("localhost","root","","basic_command");

                               // Check connection
                                  if (mysqli_connect_errno())
                                   {
                               echo "Failed to connect to MySQL: " . mysqli_connect_error();
                                   }
                                 $sql = "SELECT * FROM user";
                                 $query = mysqli_query($conn,$sql);
                                 while($row = mysqli_fetch_assoc($query)){
                                 ?>
                              <option id="<?php echo $row['userid']; ?>" value="<?php echo $row['emp_name']; ?>" class="vegi custom-select">
                                 <?php echo $row['emp_name']; ?>
                              </option>
                              <?php  }?>  
                           </select>
</td>
<td style="width: 24%">
                         <select name="product_name" id="vegitable"  class="form-control" class="btn" >
                              <?php
                              $conn = mysqli_connect("localhost","root","","db_price");
//Check connection
                                  if (mysqli_connect_errno())
                                   {
                               echo "Failed to connect to MySQL: " . mysqli_connect_error();
                                   }
                                 $sql = "SELECT * FROM product";
                                 $query = mysqli_query($conn,$sql);
                                 while($row = mysqli_fetch_assoc($query)){
                                 ?>
                              <option id="<?php echo $row['product_id']; ?>" value="<?php echo $row['product_name']; ?>" class="vegitable custom-select">
                                 <?php echo $row['product_name']; ?>
                              </option>
                              <?php  }?>  
                           </select>
       </td>

<td style="width: 10%">
                         <select name="product_price" id="vegitable"  class="form-control" class="btn" >
                              <?php
                              $conn = mysqli_connect("localhost","root","","db_price");

                                //Check connection
                                  if (mysqli_connect_errno())
                                   {
                               echo "Failed to connect to MySQL: " . mysqli_connect_error();
                                   }
                                 $sql = "SELECT * FROM product";
                                 $query = mysqli_query($conn,$sql);
                                 while($row = mysqli_fetch_assoc($query)){
                                 ?>
                              <option id="<?php echo $row['product_id']; ?>" value="<?php echo $row['product_price']; ?>" class="vegitable custom-select">
                                 <?php echo $row['product_price']; ?>
                              </option>
                              <?php  }?>  
                           </select>
</td>

<td style="width:20%">
                          <input type="number" name="product_qty" id="qty" min="0" value="0" class="form-control">
                        </td>
                        <td>
                      
                     </script>
      </table>
                        <div align="center">
                        <input type="submit" name="submit" id="add" class="btn btn-primary" value="Insert"/>
                     </div>
                  </div>
               </form>
               
            </div>
         </div>
      </div>
   </div>
</div>
</br>
</br>



   
   <tr>
<form method="post" id="insert_form">
                  <div class="table-repsonsive">
                     <span id="error"></span>

                     <table class="table table-bordered" id="item_table">
                        <tr>
                           
                         <th style="width: 10%">Employee Name</th>

                       
                        <th style="width: 10%">Product Name</th>
                       
                        <th style="width: 7%">Price</th>

                        <th style="width: 7%">Qty</th>
                        <th style="width: 7%">Total</th>
                        <th style="width: 10%">Action</th>
                  </tr>
                  <?php
                 

               
                 
$conn=mysqli_connect('localhost','root','','bill_reciept');
$query = mysqli_query($conn, "SELECT * FROM orders") or die(mysqli_error());
                  while($row = mysqli_fetch_array($query)){

                    $price=$row['product_price'];
                     $qty=$row['product_qty'];
    ?>
                  <tr>
                     <td> <?php echo $row['emp_name']; ?></td>
                     <td> <?php echo $row['product_name']; ?></td>
                     <td> <?php echo $row['product_price']; ?></td>
                     <td> <?php echo $row['product_qty']; ?></td>
                     <td class="itotal"><?php echo $total=$price*$qty?></td>
                      <td>
                &nbsp;
          <!--<button type="button" class="btn btn-danger">Danger</button>-->
               <b> <a href="delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger">D e l e t e</a></b>
              </td>
                    
</tr>

<?php } ?>
<?php
include ("total.php");
?>
 </table>
   <div align="center">
     </div>
     <!-- JavaScript Bundle with Popper -->
     <script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
   var count = 1;
     $('#add').on('click',function(){
   
        var emp_name = $('#vegi').val();
        var product_name=$('#vegitable');
        var product_price=$('#vegitable');
        var product_qty = $('#qty').val();
       
        if(qty == 0)
        {
           var erroMsg =  '<span class="alert alert-danger ml-5">Minimum Qty should be 1 or More than 1</span>';
           $('#errorMsg').html(erroMsg).fadeOut(9000);
        }
        else
        {
           billFunction(); // Below Function passing here 
        }
        
        function billFunction()
          {
          var total = 0;
      
          $("#receipt_bill").each(function () {
          var total =  price*qty;
          var subTotal = 0;
          subTotal += parseInt(total);
         
          var table =   '<tr><td>'+ count +'</td><td>'+ name + '</td><td>' + qty + '</td><td>' + price + '</td><td><strong><input type="hidden" id="total" value="'+total+'">' +total+ '</strong></td></tr>';
          $('#new').append(table)
</script>


<script type="text/javascript">
    $(document).ready(function(){      
      var postURL = "/db.php";
      var i=1;  


      $('#add').click(function(){  
           i++;  
           $('#dynamic_field').append('<tr id="row'+i+'" class="dynamic-added"><td><input type="text" name="name[]" placeholder="Enter your Name" class="form-control name_list" required /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');  
      });


      $(document).on('click', '.btn_remove', function(){  
           var button_id = $(this).attr("id");   
           $('#row'+button_id+'').remove();  
      });  


      $('#submit').click(function(){            
           $.ajax({  
                url:postURL,  
                method:"POST",  
                data:$('#add_name').serialize(),
                type:'json',
                success:function(data)  
                {
                    i=1;
                    $('.dynamic-added').remove();
                    $('#add_name')[0].reset();
                    alert('Record Inserted Successfully.');
                }  
           });  
      });


    });  
</script>









<script>
$(document).ready(function(){
 
 $(document).on('click', '.add', function(){
  var html = '';
  html += '<tr>';
 
  html += '<td><select name="emp_name[]"  class="form-control"><option value="">Select Unit</option><?php echo fill_unit_select_box($connect); ?></select></td>';
  html += '<td><button type="button" name="remove" class="btn btn-danger btn-sm remove"><span class="glyphicon glyphicon-minus"></span></button></td></tr>';
  $('#item_table').append(html);
 });
 
 $(document).on('click', '.remove', function(){
  $(this).closest('tr').remove();
 });
 
 $('#insert_form').on('submit', function(event){
  event.preventDefault();
  var error = '';
  $('.item_name').each(function(){
   var count = 1;
   if($(this).val() == '')
   {
    error += "<p>Enter Item Name at "+count+" Row</p>";
    return false;
   }
   count = count + 1;
  });
  
  $('.item_quantity').each(function(){
   var count = 1;
   if($(this).val() == '')
   {
    error += "<p>Enter Item Quantity at "+count+" Row</p>";
    return false;
   }
   count = count + 1;
  });
  
  $('.item_unit').each(function(){
   var count = 1;
   if($(this).val() == '')
   {
    error += "<p>Select Unit at "+count+" Row</p>";
    return false;
   }
   count = count + 1;
  });
  var form_data = $(this).serialize();
  if(error == '')
  {
   $.ajax({
    url:"insert.php",
    method:"POST",
    data:form_data,
    success:function(data)
    {
     if(data == 'ok')
     {
      $('#item_table').find("tr:gt(0)").remove();
      $('#error').html('<div class="alert alert-success">Item Details Saved</div>');
     }
    }
   });
  }
  else
  {
   $('#error').html('<div class="alert alert-danger">'+error+'</div>');
  }
 });
 
});
</script>