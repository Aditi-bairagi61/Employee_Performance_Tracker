<?php
	include('conn.php');
	$id=$_GET['id'];
	
	$product_name=$_POST['product_name'];
	$price=$_POST['product_price'];
	
	mysqli_query($conn,"update `product` set product_name='$product_name', product_price='$price' where product_id='$id'");
	header('location:index.php');
?>