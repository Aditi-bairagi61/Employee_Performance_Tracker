<?php
	require_once 'conn.php';
	
	
	
	if(ISSET($_POST['add'])){
		$product = $_POST['product'];
		$price = $_POST['product_price'];
		
		mysqli_query($conn, "INSERT INTO 'product'(product_name,product_price) VALUES('$product', '$price')") or die(mysqli_error());
		
		
		header("location: index.php");
	}
?>


