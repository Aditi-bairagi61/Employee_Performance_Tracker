<?php
	include('conn.php');
	$id=$_GET['id'];
	$query=mysqli_query($conn,"select * from `product` where product_id='$id'");
	$row=mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
<head>
<title>Basic MySQLi Commands</title>
 <link rel="stylesheet" href="style.css">
 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width,initial-scale=1"><br>
</head>
<style>
	input[type=submit]{
	color: #fff;
	background:#337ab7;
	padding: 7px ;
	margin-left: 10%;
	cursor: pointer;
}
	.header{
	background-color: #7792a3;
	padding: 10px;
	text-align: center;
	height: 25px;
	margin-top: -60px;
}
 #ex{
	border:10px ;
	
	padding:20px;
	background-color: #d8e8ed;
	background-repeat: no-repeat;
	background-size: 90px 100px;
	width: 450px;
	height: 100px;
	margin-left: -50px;
	background-attachment: fixed;
}
input[type=text],input[type=number]{
	display:25px;
	border:none;
	background:#f1f1f1;

}
body{
	background-color: #eee;
	background-image:url("front.jpg");
}
label{
	font-size: 18px;
}
form{
	border:solid gray 1px;
	width: 29%;
	height: 150px;
	border-radius: 2px;
	margin: 120px auto;
	background:#aeb2b8;
	padding: 50px;
}

.a{
	
	color:white;
	background-color: #7792a3;
	margin-left: -700px;
	vertical-align: text-top;
	margin-top: 20px;
	font-size: 28px;
}
a:link{
	text-decoration: none;
	font-size: 20px;
}
a:visited{
	text-decoration: none;
}
a:hover{
	text-decoration: underline;
	text-decoration-color: blue;
	background-color: #ded0a2;
}
a:active{
	color: black;
}
h2{
	text-align: left;
	margin-left: 600px;
	margin-top: 30px;
}

</style>
<body>
	<h2>Edit Record</h2>
		<div class="header">
	<form method="POST" action="update.php?id=<?php echo $id; ?>">
		<div id="ex">
		<b><label>Product Name:</label></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" value="<?php echo $row['product_name']; ?>" name="product_name"><br><br>
		<b><label>Price:</label></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" value="<?php echo $row['product_price']; ?>" name="product_price"><br><br>
	
		<b><input type="submit" name="submit"></b>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<b><a href="index.php">Back</a></b>
	</form>
</div>
</body>
</html>