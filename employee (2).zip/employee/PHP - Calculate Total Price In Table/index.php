<?php
//require_once 'conn.php';
$con=mysqli_connect("localhost", "root", "", "db_price");
if(ISSET($_POST['add'])){
$product = $_POST['product_name'];
$price = $_POST['product_price'];

mysqli_query($con,"insert into product (product_name,product_price)values('$product','$price')");

header("location: index.php");
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" href="style.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1"><br>
	<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1"/>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
</head>
<style type="">
.header{
	  background-color: #7792a3;
	padding: 10px;
	text-align: center;
	height: 63px;
	margin-top:-20px;
    background-image: url("logo3.png");
	background-size: 70px 55px;
	background-repeat: no-repeat;
	background-position: 3% 40%;
	
}
a.nav1{
	color:white;
	background-color: #7792a3;
	vertical-align: text-top;
	margin-top: 20px;
	font-family: "Times New Roman",Times,serif;
	font-size: 20px;
	position: relative;
	left: -271px;
	   margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;
	}
a.nav2{
	color:white;
	background-color: #7792a3;
	margin-left: -700px;
	vertical-align: text-top;
	margin-top: 20px;
	font-family: "Times New Roman",Times,serif;
	font-size: 20px;
	position: relative;
	right: -119px;
	  margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;
	
	}
a.nav4{
	color:white;
	background-color: #7792a3;
	margin-left: -700px;
	vertical-align: text-top;
	margin-top: 20px;
	font-family: "Times New Roman",Times,serif;
	font-size: 20px;
	position: relative;
	right: 60px;
	  margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;
	  }
	a:link{
		height: 25px;
	}
a.nav1:link{
	text-decoration: none;
}
a.nav2:link{
	text-decoration: none;
}
a.nav3:link{
	text-decoration: none;
}
a.nav4:link{
	text-decoration: none;
}
a.nav5:link{
	text-decoration: none;
}
a.nav1:visited{
	text-decoration: none;
}
a.nav2:visited{
	text-decoration: none;
}
a.nav3:visited{
	text-decoration: none;
}
a.nav4:visited{
	text-decoration: none;
}
a.nav5:visited{
	text-decoration: none;
}
a.nav1:hover{
	text-decoration: underline;
	text-decoration-color: white;
}
a.nav2:hover{
	text-decoration: underline;
	text-decoration-color: white;
}
a.nav3:hover{
	text-decoration: underline;
	text-decoration-color: white;
}
a.nav4:hover{
	text-decoration: underline;
	text-decoration-color: white;
}
a.nav5:hover{
	text-decoration: underline;
	text-decoration-color: white;
}
a.nav1:active{
	color: black;
}
a.nav2:active{
	color:black;
}
a.nav3:active{
	color:black;
}
a.nav4:active{
	color:black;
}
a.nav5:active{
	color:black;
}
a.nav3{
	margin-top: -90px;
	color:white;
	background-color: #7792a3;
	vertical-align: text-top;
	font-family: "Times New Roman",Times,serif;
	font-size: 20px;
	position: relative;
	right: 112px;
  margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;	  
}
a.nav5{
		color:white;
	background-color: #7792a3;
	margin-left: -700px;
	vertical-align: text-center;
	font-family: "Times New Roman",Times,serif;
	margin-top: 20px;
	font-size: 20px;
	position: relative;
	left: 182px;
	text-decoration: none;
	margin:1% auto;
  margin-right: auto; margin-left: auto; width: 21%; 
      padding-top: 11px;
}

</style>
	<body>
		
	<div class="header">
	
     <a class="nav2" href="\employee\PHP - Calculate Total Price In Table\index.php"><b>Add &nbsp; Product</b></a>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       <a class="nav1" href="\employee\basic_command\index.php"><b>Add&nbsp;  Employee</b></a>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <a class="nav3" href="\employee\bill_payment\index.php"><b>Employee&nbsp; Performance </b></a>   
      <a class="nav4" href="\employee\bill_payment\datedata.php"><b>Calander</b></a>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <a class="nav5"href="/employee/admin-login/index.html"><b>Logout</b></a>
 </div>
     
        <br><br><br>
		<div class="col-md-2"></div>
	    <div class="col-md-9 well">
		<h3 class="text-primary">Total Price Of Product</h3>
		<hr style="border-top:1px dotted #ccc;"/>
		<div class="col-md-4">
			<form method="POST">
				<div class="form-group">
					<b><label>Product Name</label></b>
					<input type="text" name="product_name" class="form-control" required="required"/>
				</div>
				<div class="form-group">				
					<b><label>Price</label></b>
					<input type="number" min="0" name="product_price" class="form-control" required="required"/>
				</div>
				<center><button class="btn btn-primary" name="add">Add Product</button></center>
			</form>
		</div>
		<div class="col-md-8">
			<table class="table table-bordered">
				<thead class="alert-info">
					<tr>
						<th>Product Name</th>
						<th>Price</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
						require_once 'conn.php';
						$query = mysqli_query($conn, "SELECT * FROM product") or die(mysqli_error());
						while($fetch = mysqli_fetch_array($query)){
					?>
						<tr>

							<td><?php echo $fetch['product_name']?></td>
							<td align="right"><?php echo number_format($fetch['product_price'])?></td>
							<td>
								&nbsp;
								<a href="edit.php?id=<?php echo $fetch['product_id']; ?>" class="btn btn-info" role="button">E d i t</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								<a href="delete.php?id=<?php echo $fetch['product_id']; ?>" class="btn btn-danger">D e l e t e</a>
							</td>
						</tr>
					<?php
						}
					?>
				</tbody>
				<?php include 'calculate.php'?>
			</table>
		</div>
	</div>
</body>	
</html>