<?php
	$conn=mysqli_connect("localhost", "root", "", "db_price");
	
	if(!$conn){
		die("Error: Faile to connect to database!");
	}
?>